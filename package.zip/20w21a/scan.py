import jnbt
import sys

mcnt = 0

#Open the world at <your minecraft directory>/saves/New World
world = jnbt.getWorld( "Strata.20200522" )

overworld = world[jnbt.DIM_OVERWORLD]

for region in overworld.iterRegions():
    regionShown = False
    for chunk in region.iterChunks():
        # iterate over existing references
        lock = {}
        base = chunk.nbt["Level"]["Structures"]["References"]

        chunkShown = False
        for reference in base:
            ecnt = len(base[reference])
            name = reference.lower()

            if name not in lock:
                lock[name] = ecnt
                continue
                
            if lock[name] == ecnt:
                continue
                
            if not regionShown:
                print(region)
                regionShown = True

            if not chunkShown:
                print(f'chunk, relative: [{chunk.lx}, {chunk.lz}], absolute: [{chunk.x}, {chunk.z}]')
                chunkShown = True
                
            print(f'- mismatch {name} {lock[name]} vs {ecnt}')
            mcnt += 1

    if regionShown: print()

print(f'total number of mismatches: {mcnt}', file=sys.stderr)
